//
// Created by GABRIELA on 08/11/2023.
//

#ifndef PIECEHIJAS_H
#define PIECEHIJAS_H

#include <SFML/Graphics.hpp>
#include <array>
#include <vector>
#include "piece.h"
#include "board.h"
#include "chessGame.h"

using namespace std;

class PKing:public Piece{
public:
    PKing(char type='K', bool player=true, int pos=-1, bool moved=false)
        :Piece(type,player,pos, moved){
    }
    void loadTextures()override{
        whiteKing.loadFromFile("D:/PruebaCLion/Textures/w_king.png");
        blackKing.loadFromFile("D:/PruebaCLion/Textures/b_king.png");
    }

    void calcPossibleMoves(Piece* tmpPiece)override;


private:
    static sf::Texture whiteKing;
    static sf::Texture blackKing;
    void setTexture()override{
        m_sprite.setTexture(m_player ? whiteKing : blackKing);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));//definimos el centro de la textura, el origen donde se realizaran transformaciones
        m_sprite.setScale(sf::Vector2f(0.150f,0.150)); //la sprite se escala a 0.375 veces su tamaño original, se hace mas pequeña
    }

};

class PKnight:public Piece{
public:
    PKnight(char type = 'N', bool player = true, int pos = -1, bool moved = false)
            : Piece(type, player, pos, moved) {
    }

    void loadTextures()override{
        whiteKnight.loadFromFile("D:/PruebaCLion/Textures/w_knight.png");
        blackKnight.loadFromFile("D:/PruebaCLion/Textures/b_knight.png");
    }

    void calcPossibleMoves(Piece* tmpPiece)override;

private:
    static sf::Texture whiteKnight;
    static sf::Texture blackKnight;
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteKnight:blackKnight);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }

};


//TORRE
class PRook:public Piece{
public:
    void loadTextures()override{
        whiteRook.loadFromFile("D:/PruebaCLion/Textures/w_rook.png");
        blackRook.loadFromFile("D:/PruebaCLion/Textures/b_rook.png");
    }


private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteRook:blackRook);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }

};

//PEON
class PPawn:public Piece{
public:
    void loadTextures()override{
        whitePawn.loadFromFile("D:/PruebaCLion/Textures/w_pawn.png");
        blackPawn.loadFromFile("D:/PruebaCLion/Textures/b_pawn.png");
    }

    void calcPossibleMoves(Piece* tmpPiece)override;


private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whitePawn:blackPawn);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }
};

//REINA
class PQueen:public Piece{
public:
    void loadTextures()override{
        whiteQueen.loadFromFile("D:/PruebaCLion/Textures/w_queen.png");
        blackQueen.loadFromFile("D:/PruebaCLion/Textures/b_queen.png");
    }
private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteQueen:blackQueen);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }

};

//ALFIL
class PBishop:public Piece{
public:
    void loadTextures()override{
        whiteBishop.loadFromFile("D:/PruebaCLion/Textures/w_bishop.png");
        blackBishop.loadFromFile("D:/PruebaCLion/Textures/b_bishop.png");
    }
private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteBishop:blackBishop);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }
};





#endif

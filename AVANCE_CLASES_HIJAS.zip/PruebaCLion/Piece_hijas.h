//
// Created by GABRIELA on 08/11/2023.
//

#ifndef PIECEHIJAS_H
#define PIECEHIJAS_H

#include <SFML/Graphics.hpp>
#include <array>
#include <vector>
#include "piece.h"
#include "board.h"
#include "chessGame.h"

using namespace std;


//DESHACERSE DE FUNCION 'SETPIECE', YA QUE ES REDUNDANTE

class PKing:public Piece{
public:
    PKing(char type='K', bool player=true, int pos=-1, bool moved=false)
        :Piece(type,player,pos, moved){
    }

    PKing(bool player, int pos)
            : Piece('K', player, pos, true) { // Otras inicializaciones específicas de PKing, si las hay.
    }

    void draw(sf::RenderTarget& target, sf::RenderStates states)const; //NO SÉ CÓMO IMPLEMENTARLA

    void loadTextures()override{
        whiteKing.loadFromFile("D:/PruebaCLion/Textures/w_king.png");
        blackKing.loadFromFile("D:/PruebaCLion/Textures/b_king.png");
    }

    void calcPossibleMoves(Piece* tmpPiece)override;

    void setPiece(bool player, int pos) {
        setType('K');
        setPlayer(player);
        setPosition(pos); //m_moved true
        //setMoved(false); // m_moved false

    }
private:
    static sf::Texture whiteKing;
    static sf::Texture blackKing;
    void setTexture()override{
        m_sprite.setTexture(m_player ? whiteKing : blackKing);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));//definimos el centro de la textura, el origen donde se realizaran transformaciones
        m_sprite.setScale(sf::Vector2f(0.150f,0.150)); //la sprite se escala a 0.375 veces su tamaño original, se hace mas pequeña
    }

};




class PKnight:public Piece{
public:
    PKnight(char type = 'N', bool player = true, int pos = -1, bool moved = false)
            : Piece(type, player, pos, moved) { //Es necesario poner el constructor así en la clase derivada?
    }

    PKnight(bool player, int pos)
            : Piece('N', player, pos, true) {
    }
    void loadTextures()override{
        whiteKnight.loadFromFile("D:/PruebaCLion/Textures/w_knight.png");
        blackKnight.loadFromFile("D:/PruebaCLion/Textures/b_knight.png");
    }

    void calcPossibleMoves(Piece* tmpPiece)override;

    void setPiece(bool player, int pos) {
        setType('N');
        setPlayer(player);
        setPosition(pos); //m_moved true
        //setMoved(false); // m_moved false

    }
private:
    static sf::Texture whiteKnight;
    static sf::Texture blackKnight;
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteKnight:blackKnight);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }

};


//TORRE
class PRook:public Piece{
public:
    PRook(bool player, int pos)
            : Piece('R', player, pos, true) {
    }
    void loadTextures()override{
        whiteRook.loadFromFile("D:/PruebaCLion/Textures/w_rook.png");
        blackRook.loadFromFile("D:/PruebaCLion/Textures/b_rook.png");
    }


    void setPiece(bool player, int pos) {
        setType('R');
        setPlayer(player);
        setPosition(pos); //m_moved true
        //setMoved(false); // m_moved false

    }

private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteRook:blackRook);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }

};

//PEON
class PPawn:public Piece{
public:
    PPawn(bool player, int pos)
            : Piece('P', player, pos, true) { }
    void loadTextures()override{
        whitePawn.loadFromFile("D:/PruebaCLion/Textures/w_pawn.png");
        blackPawn.loadFromFile("D:/PruebaCLion/Textures/b_pawn.png");
    }

    void calcPossibleMoves(Piece* tmpPiece)override;

    void setPiece(bool player, int pos) {
        setType('N');
        setPlayer(player);
        setPosition(pos); //m_moved true
        //setMoved(false); // m_moved false

    }


private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whitePawn:blackPawn);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }
};

//REINA
class PQueen:public Piece{
public:
    PQueen(bool player, int pos)
            : Piece('Q', player, pos, true) {
    }
    void loadTextures()override{
        whiteQueen.loadFromFile("D:/PruebaCLion/Textures/w_queen.png");
        blackQueen.loadFromFile("D:/PruebaCLion/Textures/b_queen.png");
    }

    void setPiece(bool player, int pos) {
        setType('Q');
        setPlayer(player);
        setPosition(pos); //m_moved true
        //setMoved(false); // m_moved false

    }

private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteQueen:blackQueen);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }

};

//ALFIL
class PBishop:public Piece{
public:
    PBishop(bool player, int pos)
            : Piece('B', player, pos, true) { // Otras inicializaciones específicas de PKing, si las hay.
    }
    void loadTextures()override{
        whiteBishop.loadFromFile("D:/PruebaCLion/Textures/w_bishop.png");
        blackBishop.loadFromFile("D:/PruebaCLion/Textures/b_bishop.png");
    }

    void setPiece(bool player, int pos) {
        setType('B');
        setPlayer(player);
        setPosition(pos); //m_moved true
        //setMoved(false); // m_moved false

    }
private:
    void setTexture()override{
        m_sprite.setTexture(m_player?whiteBishop:blackBishop);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
    }
};

#endif
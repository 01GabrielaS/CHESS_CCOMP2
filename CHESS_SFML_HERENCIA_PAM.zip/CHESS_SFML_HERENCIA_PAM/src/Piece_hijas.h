// piece_hijas.h

#ifndef _PIECE_HIJAS_H
#define _PIECE_HIJAS_H

#include <SFML/Graphics.hpp>
#include <array>
#include <vector>
#include "piece.h"
#include "board.h"
#include "chessGame.h"

using namespace std;


class PKing : public Piece {
public:

    static sf::Texture whiteKing;
    static sf::Texture blackKing;

    PKing(bool player, int pos) : Piece('K', player, pos) {}

    // Override loadTexture
    void loadTexture() override;

    // Override setTexture
    void setTexture() override;

};


class PQueen : public Piece {
public:

    static sf::Texture whiteQueen;
    static sf::Texture blackQueen;

    PQueen(bool player, int pos) : Piece('Q', player, pos) {}

    void loadTexture()override;

    // Override setTexture
    void setTexture()override;
};

class PRook : public Piece {
public:
    static sf::Texture whiteRook;
    static sf::Texture blackRook;

    PRook(bool player, int pos) : Piece('R', player, pos) {}

    // Override loadTexture
    void loadTexture() override;
    // Override setTexture
    void setTexture()override;
};

class PBishop : public Piece {
public:

    static sf::Texture whiteBishop;
    static sf::Texture blackBishop;

    PBishop(bool player, int pos) : Piece('B', player, pos) {}

    // Override loadTexture
    void loadTexture()override;

    // Override setTexture
    void setTexture()override;
};

class PKnight : public Piece {
public:

    static sf::Texture whiteKnight;
    static sf::Texture blackKnight;

    PKnight(bool player, int pos) : Piece('N', player, pos) {}

    // Override loadTexture
    void loadTexture()override;

    // Override setTexture
    void setTexture()override;
};

class PPawn : public Piece {
public:
    static sf::Texture whitePawn;
    static sf::Texture blackPawn;

    PPawn(bool player, int pos) : Piece('P', player, pos) {}

    // Override loadTexture
    void loadTexture()override;

    // Override setTexture
    void setTexture()override;

    void draw(sf::RenderTarget& target, sf::RenderStates states) const {
        Piece::draw(target, states);
    }
};

#endif

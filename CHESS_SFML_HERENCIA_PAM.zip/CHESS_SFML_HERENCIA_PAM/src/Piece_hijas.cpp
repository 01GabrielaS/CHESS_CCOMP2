#include "piece_hijas.h"

// Inicializar variables estáticas
sf::Texture PPawn::whitePawn;
sf::Texture PPawn::blackPawn;
sf::Texture PKing::whiteKing;
sf::Texture PKing::blackKing;
sf::Texture PQueen::whiteQueen;
sf::Texture PQueen::blackQueen;
sf::Texture PRook::whiteRook;
sf::Texture PRook::blackRook;
sf::Texture PBishop::whiteBishop;
sf::Texture PBishop::blackBishop;
sf::Texture PKnight::whiteKnight;
sf::Texture PKnight::blackKnight;



//?KING
    void PKing::loadTexture() {
        whiteKing.loadFromFile("Textures/w_king.png");
        blackKing.loadFromFile("Textures/b_king.png");
    }

    // Override setTexture
    void PKing::setTexture() {
        m_sprite.setTexture(m_player ? whiteKing : blackKing);
        Piece::setTexture();
    // Resto de la implementación...
    }


//?QUEEN

   void PQueen::loadTexture() {
        whiteQueen.loadFromFile("Textures/w_queen.png");
        blackQueen.loadFromFile("Textures/b_queen.png");
    }

    // Override setTexture
    void PQueen::setTexture() {
        m_sprite.setTexture(m_player ? whiteQueen : blackQueen);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?Rook
    void PRook::loadTexture() {
        whiteRook.loadFromFile("Textures/w_rook.png");
        blackRook.loadFromFile("Textures/b_rook.png");
    }

    // Override setTexture
    void PRook::setTexture() {
        m_sprite.setTexture(m_player ? whiteRook : blackRook);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?BISHOP
    void PBishop::loadTexture() {
        whiteBishop.loadFromFile("Textures/w_bishop.png");
        blackBishop.loadFromFile("Textures/b_bishop.png");
    }

    // Override setTexture
    void PBishop::setTexture() {
        m_sprite.setTexture(m_player ? whiteBishop : blackBishop);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?KNIGHT
    void PKnight::loadTexture() {
        whiteKnight.loadFromFile("Textures/w_knight.png");
        blackKnight.loadFromFile("Textures/b_knight.png");
    }

    // Override setTexture
    void PKnight::setTexture() {
        m_sprite.setTexture(m_player ? whiteKnight : blackKnight);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?PAWN
    // Implementación de loadTexture
    void PPawn::loadTexture() {
       whitePawn.loadFromFile("Textures/w_pawn.png");
       blackPawn.loadFromFile("Textures/b_pawn.png");
    }

    // Implementación de setTexture
    void PPawn::setTexture() {
        m_sprite.setTexture(m_player ? whitePawn : blackPawn);
        m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x/2 , m_sprite.getTexture()->getSize().y/2));//definimos el centro de la textura, el origen donde se realizaran transformaciones
        m_sprite.setScale(sf::Vector2f(0.150f,0.150));
        // Resto de la implementación...
    }
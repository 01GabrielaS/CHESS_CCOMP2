#include "piece_hijas.h"


#include "pieceTextures.h"

//?KING
    
    // Override setTexture
    void PKing::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteKing : PieceTextures::blackKing);
        Piece::setTexture();

    }
    void PKing::calcPiecePossibleMoves(){
        int piecePos{getPosition()};
        getPossibleMoves().clear();

        if((piecePos / 8) != 0){
            getPossibleMoves().push_back(piecePos - 8);
            if((piecePos % 8) != 0)
                getPossibleMoves().push_back(piecePos - 9);
            if((piecePos % 8) != 7)
                getPossibleMoves().push_back(piecePos - 7);
        }
        if((piecePos / 8) != 7){
            getPossibleMoves().push_back(piecePos + 8);
            if((piecePos % 8) != 0)
                getPossibleMoves().push_back(piecePos + 7);
            if((piecePos % 8) != 7)
                getPossibleMoves().push_back(piecePos + 9);
        }
        if((piecePos % 8) != 0)
            getPossibleMoves().push_back(piecePos - 1);
        if((piecePos % 8) != 7)
           getPossibleMoves().push_back(piecePos + 1);

        }


//?QUEEN

    // Override setTexture
    void PQueen::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteQueen : PieceTextures::blackQueen);
        Piece::setTexture();
    }

    void PQueen::calcPiecePossibleMoves(){
        /**/
        int piecePos{getPosition()};
        getPossibleMoves().clear();
        
        

        // Calcula para caminos de arriba
        for (int i = 1;(piecePos / 8 - i) >= 0; ++i) {
            int newPos = piecePos - 8 * i;
            getPossibleMoves().push_back(newPos);

        }
        // Calcula para caminos diagonales hacia arriba a la izquierda
        for (int i = 1; (piecePos / 8 - i) >= 0 && (piecePos % 8 - i) >= 0; ++i) {
            int newPos = piecePos - 9 * i;
            getPossibleMoves().push_back(newPos);

        
        }
        // Calcula para caminos diagonales hacia arriba a la derecha
        for (int i = 1; (piecePos / 8 - i) >= 0 && (piecePos % 8 + i) <= 7; ++i) {
            int newPos = piecePos - 7 * i;
            getPossibleMoves().push_back(newPos);

           
        }

        // Calcula para caminos de abajo
        for (int i = 1; (piecePos / 8 + i) <= 7; ++i) {
            int newPos = piecePos + 8 * i;
            getPossibleMoves().push_back(newPos);
        }
        // Calcula para caminos diagonales hacia abajo a la izquierda
        for (int i = 1; (piecePos / 8 + i) >= 0 && (piecePos % 8 - i) >= 0; ++i) {
            int newPos = piecePos + 7 * i;
            getPossibleMoves().push_back(newPos);

        
        }
        // Calcula para caminos diagonales hacia abajo a la derecha
        for (int i = 1; (piecePos / 8 + i) >= 0 && (piecePos % 8 + i) <= 7; ++i) {
            int newPos = piecePos + 9 * i;
            getPossibleMoves().push_back(newPos);

        
        }

        // Calcula para los costados
        for (int dir = -1; dir <= 1; dir += 2) {
            for (int i = 1; (piecePos % 8 + dir * i) >= 0 && (piecePos % 8 + dir * i) <= 7; ++i) {
                int newPos = piecePos + dir * i;
                getPossibleMoves().push_back(newPos);

            }
        }

    }

//?Rook
  

    // Override setTexture
    void PRook::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteRook : PieceTextures::blackRook);
        Piece::setTexture();
    }

    void PRook::calcPiecePossibleMoves(){
        int piecePos{getPosition()};
        getPossibleMoves().clear();
        // Calcula para caminos de arriba
        for (int i = 1;(piecePos / 8 - i) >= 0; ++i) {
            int newPos = piecePos - 8 * i;
            getPossibleMoves().push_back(newPos);

        }
        // Calcula para caminos de abajo
        for (int i = 1; (piecePos / 8 + i) <= 7; ++i) {
            int newPos = piecePos + 8 * i;
            getPossibleMoves().push_back(newPos);
        }
        // Calcula para los costados
        for (int dir = -1; dir <= 1; dir += 2) {
            for (int i = 1; (piecePos % 8 + dir * i) >= 0 && (piecePos % 8 + dir * i) <= 7; ++i) {
                int newPos = piecePos + dir * i;
                getPossibleMoves().push_back(newPos);

            }
        }

    }

//?BISHOP

    // Override setTexture
    void PBishop::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteBishop : PieceTextures::blackBishop);
        Piece::setTexture();
    // Resto de la implementación...
    }
    void PBishop::calcPiecePossibleMoves(){
        int piecePos{getPosition()};
        getPossibleMoves().clear();

        // Calcula para caminos diagonales hacia arriba a la izquierda
        for (int i = 1; (piecePos / 8 - i) >= 0 && (piecePos % 8 - i) >= 0; ++i) {
            int newPos = piecePos - 9 * i;
            getPossibleMoves().push_back(newPos);

        
        }
        // Calcula para caminos diagonales hacia arriba a la derecha
        for (int i = 1; (piecePos / 8 - i) >= 0 && (piecePos % 8 + i) <= 7; ++i) {
            int newPos = piecePos - 7 * i;
            getPossibleMoves().push_back(newPos);

           
        }
        // Calcula para caminos diagonales hacia abajo a la izquierda
        for (int i = 1; (piecePos / 8 + i) >= 0 && (piecePos % 8 - i) >= 0; ++i) {
            int newPos = piecePos + 7 * i;
            getPossibleMoves().push_back(newPos);

        
        }
        // Calcula para caminos diagonales hacia abajo a la derecha
        for (int i = 1; (piecePos / 8 + i) >= 0 && (piecePos % 8 + i) <= 7; ++i) {
            int newPos = piecePos + 9 * i;
            getPossibleMoves().push_back(newPos);

        
        }

    }

//?KNIGHT
    // Override setTexture
    void PKnight::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteKnight : PieceTextures::blackKnight);
        Piece::setTexture();
    // Resto de la implementación...
    }

    void PKnight::calcPiecePossibleMoves(){
        int piecePos{getPosition()};
        getPossibleMoves().clear();
        //todo: cambiar, yo coloque la mismas reglas del king para comprobar que funcionaba
        if((piecePos / 8) != 0){
            getPossibleMoves().push_back(piecePos - 8);
            if((piecePos % 8) != 0)
                getPossibleMoves().push_back(piecePos - 9);
            if((piecePos % 8) != 7)
                getPossibleMoves().push_back(piecePos - 7);
        }
        if((piecePos / 8) != 7){
            getPossibleMoves().push_back(piecePos + 8);
            if((piecePos % 8) != 0)
                getPossibleMoves().push_back(piecePos + 7);
            if((piecePos % 8) != 7)
                getPossibleMoves().push_back(piecePos + 9);
        }
        if((piecePos % 8) != 0)
            getPossibleMoves().push_back(piecePos - 1);
        if((piecePos % 8) != 7)
           getPossibleMoves().push_back(piecePos + 1);
    }

//?PAWN

    // Implementación de setTexture
    void PPawn::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whitePawn : PieceTextures::blackPawn);
        Piece::setTexture();
        // Resto de la implementación...
    
    }

    void PPawn::calcPiecePossibleMoves(){
        int piecePos{getPosition()};
        getPossibleMoves().clear();

        //todo: cambiar, yo coloque la mismas reglas del king para comprobar que funcionaba
        if((piecePos / 8) != 0){
            getPossibleMoves().push_back(piecePos - 8);
            if((piecePos % 8) != 0)
                getPossibleMoves().push_back(piecePos - 9);
            if((piecePos % 8) != 7)
                getPossibleMoves().push_back(piecePos - 7);
        }
        if((piecePos / 8) != 7){
            getPossibleMoves().push_back(piecePos + 8);
            if((piecePos % 8) != 0)
                getPossibleMoves().push_back(piecePos + 7);
            if((piecePos % 8) != 7)
                getPossibleMoves().push_back(piecePos + 9);
        }
        if((piecePos % 8) != 0)
            getPossibleMoves().push_back(piecePos - 1);
        if((piecePos % 8) != 7)
           getPossibleMoves().push_back(piecePos + 1);
    }
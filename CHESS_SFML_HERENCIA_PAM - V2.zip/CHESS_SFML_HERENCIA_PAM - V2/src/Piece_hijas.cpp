#include "piece_hijas.h"


#include "pieceTextures.h"

//?KING
    
    // Override setTexture
    void PKing::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteKing : PieceTextures::blackKing);
        Piece::setTexture();

    }


//?QUEEN

    // Override setTexture
    void PQueen::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteQueen : PieceTextures::blackQueen);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?Rook
  

    // Override setTexture
    void PRook::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteRook : PieceTextures::blackRook);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?BISHOP

    // Override setTexture
    void PBishop::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteBishop : PieceTextures::blackBishop);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?KNIGHT
    // Override setTexture
    void PKnight::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whiteKnight : PieceTextures::blackKnight);
        Piece::setTexture();
    // Resto de la implementación...
    }

//?PAWN

    // Implementación de setTexture
    void PPawn::setTexture() {
        m_sprite.setTexture(m_player ? PieceTextures::whitePawn : PieceTextures::blackPawn);
        Piece::setTexture();
        // Resto de la implementación...
    }
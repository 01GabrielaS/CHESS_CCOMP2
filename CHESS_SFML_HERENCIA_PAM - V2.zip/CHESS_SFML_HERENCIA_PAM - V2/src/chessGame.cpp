#include <iostream>
#include "chessGame.h"
 

ChessGame::ChessGame(sf::Color bordL_col = sf::Color::Blue, sf::Color bordD_col = sf::Color::Black)
: board(bordL_col,bordD_col)
{   
    std::cout<<"queee"<<std::endl;
    restart();
}


void ChessGame::restart(){


    selected = false;
    playerTurn = true;
    playerTurnCheck = false;
    mate = false;
    turn = 1;

    blackPieces[0] = new PRook(false, 7);
    blackPieces[1] = new PKnight(false, 6);
    blackPieces[2] = new PBishop(false, 5);
    blackPieces[3] = new PKing(false, 4);
    blackPieces[4] = new PQueen(false, 3);
    blackPieces[5] = new PBishop(false, 2);
    blackPieces[6] = new PKnight(false, 1);
    blackPieces[7] = new PRook(false, 0);

    whitePieces[0] = new PRook(true, 56);
    whitePieces[1] = new PKnight(true, 57);
    whitePieces[2] = new PBishop(true, 58);
    whitePieces[3] = new PKing(true, 59);
    whitePieces[4] = new PQueen(true, 60);
    whitePieces[5] = new PBishop(true, 61);
    whitePieces[6] = new PKnight(true, 62);
    whitePieces[7] = new PRook(true, 63);
    
    
    for(int i=8;i<16;i++){
        whitePieces[i] = new PPawn(true, 48 + (i - 8));
        blackPieces[i] = new PPawn(false, 15 - (i - 8));
    }

}

void ChessGame::draw(sf::RenderTarget& target, sf::RenderStates states) const{
    target.clear(sf::Color::Black);

    target.draw(board); //funcion draw de board


    for(int i=0;i<16;i++){
        target.draw(*whitePieces[i]);
        target.draw(*blackPieces[i]);
    }

    if (selectedPiece != NULL && selected) {
        target.draw(selectionBorder);
    }
}

bool ChessGame::selectPiece(int pos){
    // Reiniciar selección anterior
    selectedPiece = NULL;
    selected = false;


    for (int i=0;i<16;i++){
        if(playerTurn){
            if (whitePieces[i]->getPosition()==pos){
            selectedPiece = whitePieces[i]; //todo aca se quito &
            selected = true;
            break;
            }
        }
        else{
            if (blackPieces[i]->getPosition()==pos){
            selectedPiece = blackPieces[i];
            selected=true;
            break;
            }
        }
             
        selected=false;
    }

    if (!selected){
        selectedPiece=NULL;
        return selected;
    }

    createSelectSquare();
    return selected;
}


void ChessGame::createSelectSquare(){
    sf::RectangleShape tmp;
   
        selectionBorder.setSize(sf::Vector2f(64, 64)); // Tamaño del cuadro
        selectionBorder.setFillColor(sf::Color::Transparent); // Sin relleno
        selectionBorder.setOutlineColor(sf::Color::Yellow); // Contorno rojo
        selectionBorder.setOutlineThickness(-3.f); // Grosor del contorno
        int x = (selectedPiece->getPosition() % 8) * 64;
        int y = (selectedPiece->getPosition() / 8) * 64;
        selectionBorder.setPosition(x,y);
  
    

}


void ChessGame::moveSelected(int pos){
    selectedPiece->setPosition(pos);

    for(int i=0; i<16; i++){
            if(selectedPiece->getPlayer()){ 
                if(blackPieces[i]->getPosition() == pos){
                    blackPieces[i]->setPosition(-1);
                    break;
                }
            }
            else{ 
                if(whitePieces[i]->getPosition() == pos){
                    whitePieces[i]->setPosition(-1);
                    break;
                }
            }
    }

    playerTurn = !playerTurn; 

    selectedPiece = NULL;
    selected = false;

}